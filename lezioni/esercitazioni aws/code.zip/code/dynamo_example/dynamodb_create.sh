aws dynamodb create-table \
    --table-name sdccgallery \
    --attribute-definitions AttributeName=imageid,AttributeType=S \
    --key-schema AttributeName=imageid,KeyType=HASH \
    --billing-mode PAY_PER_REQUEST
