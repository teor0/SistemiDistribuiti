#!/bin/bash

URL="https://5v4mkzzbe4ifzzwwybjf5umfva0syqja.lambda-url.eu-central-1.on.aws/"

x=3
y=3

echo "pow($x,$y) =" $(curl -s "$URL?x=$x&y=$y")
